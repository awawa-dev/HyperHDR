#!/bin/bash -e
install -m 666 lut_lin_tables.3d   	"${ROOTFS_DIR}/home/pi/.hyperion"

